train <- read.csv("titanic_train.csv")
any(is.na(train))
which(!complete.cases(train))
library(Amelia)
missmap(train,main="MissingMap",col=c("yellow","black"),legand=FALSE)
#Exploratory Data Analysis
library(ggplot2)
pl <- ggplot(train,aes(Pclass)) + geom_bar(aes(fill=factor(Pclass)),fill="blue",alpha=0.5) + theme_bw() + xlab("Passenger Classes")
pl2 <- ggplot(train,aes(SibSp)) + geom_bar() + theme_bw() + xlab("Siblings and Spouses")
pl3 <- ggplot(train,aes(factor(Pclass),Age)) + geom_boxplot(aes(fill=factor(Pclass))) 
pl3 <- pl3 + theme_bw() + scale_y_continuous(breaks = seq(min(0), max(80), by = 2))
pl4 <- ggplot(train,aes(Age,Survived)) + geom_point(aes(color=factor(Pclass))) + theme_bw() + scale_x_continuous(breaks = seq(min(0), max(100), by = 2))
pl5 <- ggplot(train,aes(Survived)) + geom_bar()
pl6 <- ggplot(train,aes(Sex)) + geom_bar(aes(fill=factor(Sex)))
pl7 <- ggplot(train,aes(Age)) + geom_histogram(bins=20,alpha=0.5,fill="blue")

#Imputation of ages
imput_age <- function(age,class){
  out <- age
  for(i in 1:length(age)){
    if(is.na(age[i])==1){
      if(class[i]==1){
        out[i] <- 37
      }else if(class[i]==2){
        out[i] <- 29
      }else{
        out[i] <- 24
      }
    }else{
      out[i] <- age[i]
    }
  }
  return(out)
}

fixed.ages <- imput_age(train$Age,train$Pclass)
train$Age <- fixed.ages
missmap(train,main="Imputation Check",col=c("yellow","black"),legand=FALSE)
library(dplyr)
train <- select(train,-PassengerId,-Name,-Ticket,-Cabin)

train$Survived <- factor(train$Survived)
train$Pclass <- factor(train$Pclass)
train$SibSp <- factor(train$SibSp)
train$Parch <- factor(train$Parch)
 
log.model <- glm(Survived ~ .,family=binomial(link="logit"),train)
summary(log.model)

test <- read.csv("titanic_test.csv")
#any(is.na(test))
#missmap(test,main="Missing Map in test",col=c("yellow","black"),legend=FALSE)
test$Age <- imput_age(test$Age,test$Pclass)
#which(!complete.cases(test$Age))
missmap(test,main="Missing Map in test",col=c("yellow","black"),legend=FALSE)

Fare <- function(fare){
  out <- fare
  for( i in 1:length(fare)){
    if(is.na(fare[i])==TRUE){
      out[i] <- 7.2250
    }else{
      out[i] <- fare[i]
    }
  }
  return(out)
} 
test$Fare <- Fare(test$Fare)

missmap(test,main="Missing Map in test - final check",col=c("yellow","black"),legend=FALSE)

test$Pclass <- factor(test$Pclass)
test$SibSp <- factor(test$SibSp)
test$Parch <- factor(test$Parch)
test <- select(test,-PassengerId,-Name,-Ticket,-Cabin)


log.predict <- predict(log.model,test,type = "response")
result <- ifelse(log.predict>0.5,1,0)

#Accuracy
missClassError <- mean(result == test)
print(1 - missClassError)


