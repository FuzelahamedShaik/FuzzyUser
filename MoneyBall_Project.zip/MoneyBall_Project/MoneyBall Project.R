library(data.table)
library(dplyr)
batting <- read.csv("Batting.csv")
batting$BA <- batting$H/batting$AB
batting$OBP <- (batting$H+batting$BB+batting$HBP)/(batting$AB+batting$BB+batting$HBP+batting$SF)
batting$X1B <- batting$H-batting$X2B-batting$X3B-batting$HR
batting$SLG <- ((1*batting$X1B)+(2*batting$X2B)+(3*batting$X3B)+(4*batting$HR))/batting$AB
sal <- read.csv("Salaries.csv")
batting <- subset(batting,yearID>=1985)
combo <- merge(batting,sal,by=c("playerID","yearID"))
lost_players <- subset(combo,playerID %in% c("giambja01","damonjo01","saenzol01"))
lost_players <- subset(lost_players,yearID==2001)
lost_players <- select(lost_players,playerID,H,X2B,X3B,HR,OBP,SLG,BA,AB)
combo <- subset(combo,yearID==2001)
requried_AB <- sum(lost_players$AB)/3
combo <- subset(combo,AB>=requried_AB)
combo <- subset(combo,OBP>=mean(lost_players$OBP))
combo <- subset(combo,salary<=(15000000/3)) 
combo <- subset(combo,!(playerID %in% c("giambja01","damonjo01","saenzol01")))
final <- arrange(combo,desc(OBP))
print(head(final,10))

library(ggplot2)
pl <- ggplot(final,aes(playerID,salary)) + geom_point(aes(color=playerID),size=5,alpha=1) + theme_gray()
print(pl)

pl2 <- ggplot(final,aes(playerID,AB)) + geom_point(aes(color=playerID),size=5,alpha=1)+ ylab("At Bat") + theme_gray()
print(pl2)

pl3 <- ggplot(final,aes(playerID,OBP)) + geom_point(aes(color=playerID),size=5,alpha=1)+ ylab("One Base Percentage") + theme_gray()
print(pl3)

pl4 <- ggplot(final,aes(salary,OBP)) + geom_point(aes(color=playerID),size=5,alpha=1)+ ylab("One Base Percentage") + theme_gray()
print(pl4 + ggtitle("OBP vs Salary for different players"))


