df <- read.csv("student-mat.csv",sep=";")
any(is.na(df)) #No NA values so return FALSE
library(ggplot2)
library(ggthemes)
library(dplyr)
library(corrgram)
library(corrplot)
num.cols <- sapply(df,is.numeric)
#filter for correlation
cor.data <- cor(df[,num.cols])
print(cor.data)
print(corrplot(cor.data,method="color"))
corrgram(df,order=TRUE,lower.panel=panel.pie,upper.panel=panel.shade,text.panel=panel.txt)

pl <- ggplot(df,aes(G3)) + geom_histogram(bins=20,alpha=0.5,fill="blue")
print(pl)

#Split data into train and test set
library(caTools)
#set a seed
set.seed(101)
#split up sample
sample <- sample.split(df$G3,SplitRatio = 0.7)
#70% of data is train
train <- subset(df,sample==TRUE)
#30% of data is test
test <- subset(df,sample==FALSE)
#train and build model
model <- lm(G3~.,train)
res <- residuals(model)
res <- as.data.frame(res)
pl <- ggplot(res,aes(res)) + geom_histogram(fill="blue")

G3.prediction <- predict(model,test)
result <- cbind(G3.prediction,test$G3)
colnames(result) <- c("Predicted","Actual")
result <- as.data.frame(result)
to_zero <- function(x){
  if(x < 0){
    return(0)
  }else{
    return(x)
  }
}
result$Predicted <- sapply(result$Predicted,to_zero)
sse <- sum((result$Predicted-result$Actual)^2)
sst <- sum((mean(df$G3)-result$Actual)^2)
covariance <- 1-(sse/sst)
print(covariance)



